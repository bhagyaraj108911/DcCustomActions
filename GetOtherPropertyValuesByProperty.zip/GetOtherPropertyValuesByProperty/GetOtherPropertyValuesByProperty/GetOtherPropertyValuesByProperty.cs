﻿//
// Licensed Materials - Property of IBM
//
// 5725-C15
// © Copyright IBM Corp. 1994, 2014 All Rights Reserved
// US Government Users Restricted Rights - Use, duplication or
// disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
//
// This is an example of a .NET action for IBM Datacap using .NET 4.0.
// The compliled DLL needs to be placed into the RRS directory.
// The DLL does not need to be registered.  
// Datacap studio will find the RRX file that is embedded in the DLL, you do not need to place the RRX in the RRS directory.
// If you add references to other DLLs, such as 3rd party, you may need to place those DLLs in C:\RRS so they are found at runtime.
// If Datacap references are not found at compile time, add a reference path of C:\Datacap\DCShared\NET to the project to locate the DLLs while building.
// This template has been tested with IBM Datacap 9.0.  

using System;
using System.Runtime.InteropServices;
using System.Net;
using System.Windows.Forms;
using System.Diagnostics;
using System.Reflection;
using P8_Connection;
using FileNet.Api.Query;
using FileNet.Api.Core;
using FileNet.Api.Collection;

namespace GetOtherPropertyValuesByProperty
{
    public class CustomAction // This class must be a base class for .NET 4.0 Actions.
    {
        #region ExpectedByRRS
        /// <summary/>
        ~CustomAction()
        {
            DatacapRRCleanupTime = true;
        }

        /// <summary>
        /// Cleanup: This property is set right before the object is released by RRS
        /// </summary>
        public bool DatacapRRCleanupTime
        {
            set
            {
                if (value)
                {
                    CurrentDCO = null;
                    DCO = null;
                    RRLog = null;
                    RRState = null;
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
            }
        }

        protected PILOTCTRLLib.IBPilotCtrl BatchPilot = null;
        public PILOTCTRLLib.IBPilotCtrl DatacapRRBatchPilot { set { this.BatchPilot = value; GC.Collect(); GC.WaitForPendingFinalizers(); } get { return this.BatchPilot; } }

        protected TDCOLib.IDCO DCO = null;
        /// <summary/>
        public TDCOLib.IDCO DatacapRRDCO
        {
            get { return this.DCO; }
            set
            {
                DCO = value;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        protected dcrroLib.IRRState RRState = null;
        /// <summary/>
        public dcrroLib.IRRState DatacapRRState
        {
            get { return this.RRState; }
            set
            {
                RRState = value;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        public TDCOLib.IDCO CurrentDCO = null;
        /// <summary/>
        public TDCOLib.IDCO DatacapRRCurrentDCO
        {
            get { return this.CurrentDCO; }
            set
            {
                CurrentDCO = value;
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        public dclogXLib.IDCLog RRLog = null;
        /// <summary/>
        public dclogXLib.IDCLog DatacapRRLog
        {
            get { return this.RRLog; }
            set
            {
                RRLog = value;
                LogAssemblyVersion();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }
        }

        #endregion

        #region CommonActions

        void OutputToLog(int nLevel, string strMessage)
        {
            if (null == RRLog)
                return;
            RRLog.WriteEx(nLevel, strMessage);
        }

        public void WriteLog(string sMessage)
        {
            OutputToLog(5, sMessage);
        }

        private bool versionWasLogged = false;

        // Log the version of the library that was running to help with diagnosis.
        // Hooked this method to be called after the log object is assigned.  Also put in
        // a check that this action runs only once, just in case it gets called multiple times.
        protected bool LogAssemblyVersion()
        {
            try
            {
                if (versionWasLogged == false)
                {
                    FileVersionInfo fv = System.Diagnostics.FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
                    WriteLog(Assembly.GetExecutingAssembly().Location +
                             ". AssemblyVersion: " + Assembly.GetExecutingAssembly().GetName().Version.ToString() +
                             ". AssemblyFileVersion: " + fv.FileVersion.ToString() + ".");
                    versionWasLogged = true;
                }
            }
            catch (Exception ex)
            {
                WriteLog("Version logging exception: " + ex.Message);
            }

            // We can always return true.  If getting the version fails, we can try to continue anyway.
            return true;
        }

        #endregion


        //implementation of the Dispose method to release managed resources
        public void Dispose()
        {
        }

        struct Level
        {
            internal const int Batch = 0;
            internal const int Document = 1;
            internal const int Page = 2;
            internal const int Field = 3;
        }

        P8Connection objP8_Con = new P8Connection();
        public bool GetOtherPropertyValuesByProperty(string mtomURL, string userName, string password, string osName, string docClass, string propertyWithValue, string property, string aliasName, bool includeSubClass)
        {
            bool bRet = false;
            dcSmart.SmartNav SmartObj = null;
            try
            {
                if (CurrentDCO.ObjectType() == Level.Field)
                {
                    WriteLog("GetOtherPropertyValuesByProperty:: Action should not be at Field level.");
                    return bRet;
                }      
                SmartObj = new dcSmart.SmartNav(this);
                //collecting all smart values
                mtomURL = SmartObj.MetaWord(mtomURL);
                WriteLog("mtomURL " + mtomURL);
                userName = SmartObj.MetaWord(userName);
                WriteLog("userName " + userName);
                password = SmartObj.MetaWord(password);
                osName = SmartObj.MetaWord(osName);
                WriteLog("osName " + osName);
                docClass = SmartObj.MetaWord(docClass);
                WriteLog("docClass " + docClass);
                propertyWithValue = SmartObj.MetaWord(propertyWithValue);
                WriteLog("propertyWithValue " + propertyWithValue);
                property = SmartObj.MetaWord(property);
                WriteLog("property " + property);
                aliasName = SmartObj.MetaWord(aliasName);
                WriteLog("aliasName " + aliasName);

                //if connection fails returning false
                if (!Get_Login(mtomURL, userName, password, osName))
                {
                     return bRet;
                }
                IObjectStore ObjectSname = P8Connection.Op_OS;
                SearchSQL sqlObj = new SearchSQL();
                string select = property;
                sqlObj.SetSelectList(select);


                sqlObj.SetFromClauseInitialValue(docClass, aliasName, includeSubClass);
                sqlObj.SetWhereClause(propertyWithValue);
                WriteLog("Sql Results "+sqlObj.ToString());

                SearchScope searchScope = new SearchScope(ObjectSname);
                IRepositoryRowSet rowSet = searchScope.FetchRows(sqlObj, null, null, null);

                int rowCount = 0;
                property = property.Replace(aliasName + ".", "");
                foreach(IRepositoryRow row in rowSet)
                {
                    rowCount++;
                    CurrentDCO.set_Variable(property + "_" + rowCount, row.Properties.GetProperty(property).ToString());
                }
                WriteLog("All Property Values are collected.");

                bRet = true;
            }
            catch(Exception ex)
            {
                WriteLog("Exception occured, exception message " + ex.Message.ToString());
            }
            return bRet;
        }

        public bool Get_Login(string mtom, string username, string password, string osname)
        {
            try
            {
                if (P8Connection.Op_OS == null)
                { objP8_Con.Fnp8_Login(mtom, username, password, osname); }
                if (P8Connection.Op_OS != null)
                { WriteLog("Authentication Success..."); return true; }
                else
                { WriteLog("Authentication Failed..."); return false; }
            }
            catch (Exception ex)
            { WriteLog("Authentication Failed..." + ex.Message.ToString()); return false; }

        }
    }
}
