﻿using FileNet.Api.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Web.Services3.Security.Tokens;
using FileNet.Api.Util;

namespace P8_Connection
{
    class P8Connection
    {
        public static IConnection Op_CECon;
        public static IDomain Op_Domain;
        public static IObjectStore Op_OS;
        #region Login Connection
        public IObjectStore Fnp8_Login(string url, string userName, string pwd, string osName)
        {
            UsernameToken UserToken = default(UsernameToken);
            try
            {
                UserToken = new UsernameToken(userName, pwd, PasswordOption.SendPlainText);
                UserContext.SetProcessSecurityToken(UserToken);
                Op_CECon = Factory.Connection.GetConnection(url);
                Op_Domain = Factory.Domain.GetInstance(Op_CECon, null);
                Op_OS = Factory.ObjectStore.FetchInstance(Op_Domain, osName, null);
                return Op_OS;
            }
            catch (Exception ex)
            { return Op_OS; }
        }
        #endregion
    }
}
